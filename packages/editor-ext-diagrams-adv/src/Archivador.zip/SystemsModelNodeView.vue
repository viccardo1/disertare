<!-- packages/editor-ext-diagrams-adv/src/SystemsModelNodeView.vue -->
<template>
  <div class="diagram-systems-model">
    <p class="diagram-systems-model__hint">
      Vista simplificada de modelo / análisis de sistemas
      (diagramas causales, caja negra, componentes).
    </p>
  </div>
</template>

<script setup lang="ts">
defineProps<{
  node: any
}>()
</script>

<style scoped>
.diagram-systems-model__hint {
  font-size: 11px;
  color: #4b5563;
}
</style>
