<!-- packages/editor-ext-diagrams-adv/src/VennEulerNodeView.vue -->
<template>
  <div class="diagram-venn">
    <!-- Descripción / título general del diagrama -->
    <div class="diagram-venn__header">
      <div class="diagram-venn__title-block">
        <strong class="diagram-venn__title">
          {{ node.attrs.title || 'Diagrama de Venn / Euler' }}
        </strong>
        <p v-if="node.attrs.description" class="diagram-venn__description">
          {{ node.attrs.description }}
        </p>
      </div>

      <span class="diagram-venn__chip">
        {{ templateLabel }}
      </span>
    </div>

    <!-- Zona de edición “tabular” de conjuntos / elementos -->
    <div class="diagram-venn__sets">
      <div
        v-for="(set, index) in sets"
        :key="set.id"
        class="diagram-venn__set"
      >
        <label class="diagram-venn__set-label">
          Conjunto {{ String.fromCharCode(65 + index) }}
        </label>

        <input
          v-model="set.label"
          type="text"
          class="diagram-venn__input diagram-venn__input--set-name"
          placeholder="Nombre del conjunto (ej. Estudiantes)"
          @input="onSetLabelChange"
        />

        <div class="diagram-venn__items">
          <label class="diagram-venn__items-label">
            Elementos del conjunto
          </label>

          <div
            v-for="(item, itemIndex) in set.items"
            :key="itemIndex"
            class="diagram-venn__item-row"
          >
            <input
              v-model="set.items[itemIndex]"
              type="text"
              class="diagram-venn__input diagram-venn__input--item"
              placeholder="Elemento (ej. Aprobado en Matemáticas)"
              @input="onItemsChange"
            />
          </div>

          <button
            type="button"
            class="diagram-venn__btn-add"
            @click="addItem(set.id)"
          >
            +
            <span class="diagram-venn__btn-add-text">
              Agregar elemento
            </span>
          </button>
        </div>
      </div>
    </div>

    <p class="diagram-venn__footnote">
      Vista simplificada de diagrama de Venn/Euler. Cada conjunto y sus
      elementos se pueden editar desde este nodo. La configuración avanzada de
      intersecciones y estilos específicos continúa dentro de la misma F2.11.
    </p>
  </div>
</template>

<script setup lang="ts">
import { computed, reactive, watch } from 'vue'

const props = defineProps<{
  node: any
  /**
   * Inyectado por DiagramAdvNodeView.vue (TipTap NodeView).
   * Lo tratamos como opcional por seguridad.
   */
  updateAttributes?: (attrs: Record<string, unknown>) => void
}>()

type VennSet = {
  id: string
  label: string
  items: string[]
}

type VennConfig = {
  template: string
  sets: VennSet[]
}

/**
 * Plantillas por defecto para 2 o 3 conjuntos.
 */
function defaultConfigForTemplate(template: string): VennConfig {
  if (template === 'venn-2-basic') {
    return {
      template,
      sets: [
        {
          id: 'setA',
          label: 'Conjunto A',
          items: [''],
        },
        {
          id: 'setB',
          label: 'Conjunto B',
          items: [''],
        },
      ],
    }
  }

  // Por defecto usamos 3 conjuntos
  return {
    template: template || 'venn-3-basic',
    sets: [
      {
        id: 'setA',
        label: 'Conjunto A',
        items: [''],
      },
      {
        id: 'setB',
        label: 'Conjunto B',
        items: [''],
      },
      {
        id: 'setC',
        label: 'Conjunto C',
        items: [''],
      },
    ],
  }
}

/**
 * Leemos la configuración desde attrs.config.venn (nuevo),
 * o generamos una por defecto si no existe aún.
 */
const initialTemplate = computed<string>(() => {
  return (
    props.node.attrs.template ||
    props.node.attrs.config?.venn?.template ||
    'venn-3-basic'
  )
})

const state = reactive<VennConfig>(
  (() => {
    const cfg = props.node.attrs.config?.venn as VennConfig | undefined
    if (cfg && Array.isArray(cfg.sets) && cfg.sets.length > 0) {
      return {
        template: cfg.template || initialTemplate.value,
        sets: cfg.sets.map((s) => ({
          id: s.id,
          label: s.label || '',
          items: Array.isArray(s.items) && s.items.length > 0 ? s.items : [''],
        })),
      }
    }

    return defaultConfigForTemplate(initialTemplate.value)
  })(),
)

/**
 * Atajo para el template actual y los conjuntos reactivos.
 */
const templateLabel = computed(() => {
  if (state.template === 'venn-2-basic') {
    return 'Venn básico (2 conjuntos)'
  }
  if (state.template === 'venn-3-basic') {
    return 'Venn básico (3 conjuntos)'
  }
  return state.template || 'Venn / Euler'
})

const sets = computed(() => state.sets)

/**
 * Sincronizar cualquier cambio con el documento (attrs.config.venn).
 */
function emitUpdate() {
  if (!props.updateAttributes) return

  props.updateAttributes({
    template: state.template,
    config: {
      // mantenemos cualquier otra configuración de otros tipos
      ...(props.node.attrs.config || {}),
      venn: {
        template: state.template,
        sets: state.sets.map((s) => ({
          id: s.id,
          label: s.label,
          items: s.items,
        })),
      },
    },
  })
}

watch(
  () => state,
  () => {
    emitUpdate()
  },
  { deep: true },
)

/**
 * Handlers
 */
function addItem(setId: string) {
  const target = state.sets.find((s) => s.id === setId)
  if (!target) return
  target.items.push('')
  emitUpdate()
}

function onSetLabelChange() {
  emitUpdate()
}

function onItemsChange() {
  emitUpdate()
}
</script>

<style scoped>
.diagram-venn {
  display: flex;
  flex-direction: column;
  gap: 10px;
  padding: 10px 14px;
  border-radius: 8px;
  background: #f9fafb;
}

.diagram-venn__header {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: 12px;
}

.diagram-venn__title-block {
  display: flex;
  flex-direction: column;
  gap: 2px;
}

.diagram-venn__title {
  font-size: 13px;
  color: #111827;
}

.diagram-venn__description {
  font-size: 11px;
  color: #4b5563;
}

.diagram-venn__chip {
  align-self: flex-start;
  padding: 2px 8px;
  border-radius: 999px;
  font-size: 10px;
  background: #eef2ff;
  color: #3730a3;
  border: 1px solid #c7d2fe;
}

.diagram-venn__sets {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(210px, 1fr));
  gap: 12px;
}

.diagram-venn__set {
  padding: 8px;
  border-radius: 8px;
  background: #ffffff;
  border: 1px dashed #e5e7eb;
}

.diagram-venn__set-label {
  font-size: 11px;
  font-weight: 600;
  color: #4b5563;
}

.diagram-venn__input {
  width: 100%;
  border-radius: 6px;
  border: 1px solid #e5e7eb;
  padding: 4px 6px;
  font-size: 11px;
  margin-top: 4px;
}

.diagram-venn__input--set-name {
  font-weight: 500;
}

.diagram-venn__items {
  margin-top: 8px;
}

.diagram-venn__items-label {
  font-size: 10px;
  color: #6b7280;
}

.diagram-venn__item-row {
  margin-top: 4px;
}

.diagram-venn__btn-add {
  margin-top: 6px;
  border-radius: 999px;
  border: 1px dashed #c7d2fe;
  background: #eef2ff;
  font-size: 10px;
  padding: 2px 6px;
  cursor: pointer;
  display: inline-flex;
  align-items: center;
  gap: 4px;
  color: #3730a3;
}

.diagram-venn__btn-add-text {
  font-weight: 500;
}

.diagram-venn__footnote {
  margin-top: 6px;
  font-size: 10px;
  color: #6b7280;
}
</style>
