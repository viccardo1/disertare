<!-- packages/editor-ext-diagrams-adv/src/IshikawaNodeView.vue -->
<template>
  <NodeViewWrapper class="diagram-ishikawa">
    <!-- Encabezado: título + descripción/efecto principal -->
    <header class="diagram-ishikawa__header">
      <input
        class="diagram-ishikawa__title"
        type="text"
        :value="title"
        placeholder="Diagrama avanzado"
        @input="onTitleInput(($event.target as HTMLInputElement).value)"
      />

      <input
        class="diagram-ishikawa__description"
        type="text"
        :value="description"
        placeholder="Descripción / efecto principal (opcional)"
        @input="onDescriptionInput(($event.target as HTMLInputElement).value)"
      />
    </header>

    <!-- Cuerpo del diagrama -->
    <div class="diagram-ishikawa__body">
      <!-- Lado izquierdo: 3 categorías -->
      <div class="diagram-ishikawa__side diagram-ishikawa__side--left">
        <div
          v-for="(cat, index) in leftCategories"
          :key="cat.key"
          class="diagram-ishikawa__branch diagram-ishikawa__branch--left"
        >
          <div class="diagram-ishikawa__branch-label">
            <input
              type="text"
              :value="cat.label"
              @input="
                onCategoryLabelInput(
                  index,
                  ($event.target as HTMLInputElement).value,
                )
              "
            />
          </div>

          <ul class="diagram-ishikawa__causes">
            <li
              v-for="(cause, causeIndex) in cat.items"
              :key="`${cat.key}-${causeIndex}`"
            >
              <input
                type="text"
                :value="cause"
                placeholder="Causa..."
                @input="
                  onCauseInput(
                    index,
                    causeIndex,
                    ($event.target as HTMLInputElement).value,
                  )
                "
              />
            </li>
          </ul>

          <button
            type="button"
            class="diagram-ishikawa__add-cause"
            @click="addCause(index)"
          >
            +
          </button>
        </div>
      </div>

      <!-- Centro: espina + efecto -->
      <div class="diagram-ishikawa__center">
        <div class="diagram-ishikawa__spine" />

        <div class="diagram-ishikawa__effect-box">
          <textarea
            :value="effect"
            class="diagram-ishikawa__effect-input"
            placeholder="Efecto / problema principal"
            @input="
              onEffectInput(($event.target as HTMLTextAreaElement).value)
            "
          />
        </div>
      </div>

      <!-- Lado derecho: 3 categorías -->
      <div class="diagram-ishikawa__side diagram-ishikawa__side--right">
        <div
          v-for="(cat, index) in rightCategories"
          :key="cat.key"
          class="diagram-ishikawa__branch diagram-ishikawa__branch--right"
        >
          <div class="diagram-ishikawa__branch-label">
            <input
              type="text"
              :value="cat.label"
              @input="
                onCategoryLabelInput(
                  index + leftCategories.length,
                  ($event.target as HTMLInputElement).value,
                )
              "
            />
          </div>

          <ul class="diagram-ishikawa__causes">
            <li
              v-for="(cause, causeIndex) in cat.items"
              :key="`${cat.key}-${causeIndex}`"
            >
              <input
                type="text"
                :value="cause"
                placeholder="Causa..."
                @input="
                  onCauseInput(
                    index + leftCategories.length,
                    causeIndex,
                    ($event.target as HTMLInputElement).value,
                  )
                "
              />
            </li>
          </ul>

          <button
            type="button"
            class="diagram-ishikawa__add-cause"
            @click="addCause(index + leftCategories.length)"
          >
            +
          </button>
        </div>
      </div>
    </div>

    <footer class="diagram-ishikawa__footer">
      Vista simplificada de Diagrama de Ishikawa (causa–efecto).
      Las ramas (categorías) e ítems son editables desde este nodo.
      La personalización avanzada de plantillas continúa dentro de F2.11.
    </footer>
  </NodeViewWrapper>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import { NodeViewWrapper } from '@tiptap/vue-3'

type IshikawaCategory = {
  key: string
  label: string
  items: string[]
}

const DEFAULT_CATEGORIES: IshikawaCategory[] = [
  {
    key: 'metodo',
    label: 'Método',
    items: [''],
  },
  {
    key: 'mano-obra',
    label: 'Mano de obra',
    items: [''],
  },
  {
    key: 'maquinaria',
    label: 'Maquinaria',
    items: [''],
  },
  {
    key: 'medicion',
    label: 'Medición',
    items: [''],
  },
  {
    key: 'medio-ambiente',
    label: 'Medio ambiente',
    items: [''],
  },
  {
    key: 'materiales',
    label: 'Materiales',
    items: [''],
  },
]

const props = defineProps<{
  node: any
  updateAttributes: (attrs: Record<string, any>) => void
}>()

const title = computed(
  () => props.node.attrs.title ?? 'Diagrama avanzado',
)

const description = computed(
  () => props.node.attrs.description ?? '',
)

const effect = computed(
  () => props.node.attrs.effect ?? 'Efecto / problema principal',
)

const categories = computed<IshikawaCategory[]>(() => {
  const raw = props.node.attrs.categories as IshikawaCategory[] | undefined
  if (!raw || !Array.isArray(raw) || raw.length === 0) {
    return DEFAULT_CATEGORIES
  }

  // Normalizar: siempre 6 elementos
  const merged: IshikawaCategory[] = DEFAULT_CATEGORIES.map(
    (def, index) => ({
      key: raw[index]?.key ?? def.key,
      label: raw[index]?.label ?? def.label,
      items:
        Array.isArray(raw[index]?.items) && raw[index]!.items.length > 0
          ? [...raw[index]!.items]
          : [...def.items],
    }),
  )

  return merged
})

const leftCategories = computed(() => categories.value.slice(0, 3))
const rightCategories = computed(() => categories.value.slice(3))

function commitCategories(next: IshikawaCategory[]) {
  props.updateAttributes({
    categories: next,
  })
}

function onTitleInput(value: string) {
  props.updateAttributes({ title: value })
}

function onDescriptionInput(value: string) {
  props.updateAttributes({ description: value })
}

function onEffectInput(value: string) {
  props.updateAttributes({ effect: value })
}

function onCategoryLabelInput(index: number, value: string) {
  const next = [...categories.value]
  next[index] = {
    ...next[index],
    label: value,
  }
  commitCategories(next)
}

function onCauseInput(index: number, causeIndex: number, value: string) {
  const next = [...categories.value]
  const cat = next[index]
  if (!cat) return

  const items = [...cat.items]
  items[causeIndex] = value

  next[index] = {
    ...cat,
    items,
  }

  commitCategories(next)
}

function addCause(index: number) {
  const next = [...categories.value]
  const cat = next[index]
  if (!cat) return

  next[index] = {
    ...cat,
    items: [...cat.items, ''],
  }

  commitCategories(next)
}
</script>

<style scoped>
.diagram-ishikawa {
  border-radius: 8px;
  border: 1px solid #e5e7eb;
  background: #ffffff;
  padding: 12px;
  font-family: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI',
    sans-serif;
  font-size: 12px;
  color: #111827;
}

.diagram-ishikawa__header {
  display: flex;
  flex-direction: column;
  gap: 4px;
  margin-bottom: 10px;
}

.diagram-ishikawa__title {
  font-weight: 600;
  font-size: 13px;
  border-radius: 6px;
  border: 1px solid #e5e7eb;
  padding: 4px 8px;
}

.diagram-ishikawa__description {
  border-radius: 6px;
  border: 1px dashed #e5e7eb;
  padding: 4px 8px;
  font-size: 12px;
}

.diagram-ishikawa__body {
  display: grid;
  grid-template-columns: 1fr auto 1fr;
  gap: 8px;
  align-items: center;
  margin-bottom: 8px;
}

/* Centro */

.diagram-ishikawa__center {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 8px;
}

.diagram-ishikawa__spine {
  width: 2px;
  height: 80px;
  background: #4b5563;
}

.diagram-ishikawa__effect-box {
  border-radius: 8px;
  border: 1px solid #d1d5db;
  padding: 6px 10px;
  min-width: 160px;
  text-align: center;
  background: #f9fafb;
}

.diagram-ishikawa__effect-input {
  width: 100%;
  border: none;
  background: transparent;
  resize: none;
  text-align: center;
  font-size: 12px;
  line-height: 1.3;
}

/* Lados / ramas */

.diagram-ishikawa__side {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.diagram-ishikawa__branch {
  position: relative;
  padding: 4px 8px 4px 0;
}

.diagram-ishikawa__branch--left::after,
.diagram-ishikawa__branch--right::after {
  content: '';
  position: absolute;
  top: 50%;
  width: 40px;
  height: 1px;
  background: #6b7280;
}

.diagram-ishikawa__branch--left::after {
  right: -8px;
}

.diagram-ishikawa__branch--right::after {
  left: -8px;
}

.diagram-ishikawa__branch-label input {
  width: 100%;
  border-radius: 999px;
  border: 1px solid #e5e7eb;
  padding: 2px 8px;
  font-size: 11px;
  font-weight: 600;
  background: #f9fafb;
}

.diagram-ishikawa__causes {
  list-style: none;
  margin: 4px 0 0;
  padding: 0;
  display: flex;
  flex-direction: column;
  gap: 2px;
}

.diagram-ishikawa__causes input {
  width: 100%;
  border-radius: 4px;
  border: 1px dashed #e5e7eb;
  padding: 2px 6px;
  font-size: 11px;
}

.diagram-ishikawa__add-cause {
  margin-top: 2px;
  border-radius: 999px;
  border: 1px solid #e5e7eb;
  background: #f9fafb;
  font-size: 11px;
  width: 18px;
  height: 18px;
  line-height: 1;
  cursor: pointer;
}

/* Footer */

.diagram-ishikawa__footer {
  margin-top: 4px;
  font-size: 10px;
  color: #6b7280;
}
</style>
