<!-- packages/editor-ext-diagrams-adv/src/ProcessMapNodeView.vue -->
<template>
  <NodeViewWrapper class="diagram-process">
    <header class="diagram-process__header">
      <input
        v-model="localTitle"
        type="text"
        class="diagram-process__title-input"
        :placeholder="'Título del proceso (opcional)'"
        @blur="commitTitle"
      />

      <textarea
        v-model="localDescription"
        class="diagram-process__description-input"
        :placeholder="'Descripción general del proceso (opcional)'"
        rows="2"
        @blur="commitDescription"
      />
    </header>

    <div class="diagram-process__toolbar">
      <button
        type="button"
        class="diagram-process__btn"
        @click="addStep('start')"
      >
        + Inicio
      </button>
      <button
        type="button"
        class="diagram-process__btn"
        @click="addStep('process')"
      >
        + Paso
      </button>
      <button
        type="button"
        class="diagram-process__btn"
        @click="addStep('decision')"
      >
        + Decisión
      </button>
      <button
        type="button"
        class="diagram-process__btn"
        @click="addStep('end')"
      >
        + Fin
      </button>
    </div>

    <div class="diagram-process__flow">
      <div
        v-for="(step, index) in steps"
        :key="step.id"
        class="diagram-process__step-wrapper"
      >
        <div
          :class="[
            'diagram-process__step',
            `diagram-process__step--${step.kind}`,
          ]"
        >
          <div class="diagram-process__step-kind">
            {{ kindLabel(step.kind) }}
          </div>
          <div class="diagram-process__step-label">
            {{ step.label }}
          </div>
          <div class="diagram-process__step-actions">
            <button
              type="button"
              class="diagram-process__step-btn"
              @click.stop="editStep(step.id)"
            >
              ✏️
            </button>
            <button
              type="button"
              class="diagram-process__step-btn"
              @click.stop="removeStep(step.id)"
            >
              ✕
            </button>
            <button
              v-if="index > 0"
              type="button"
              class="diagram-process__step-btn"
              @click.stop="moveStep(step.id, -1)"
            >
              ⬅
            </button>
            <button
              v-if="index < steps.length - 1"
              type="button"
              class="diagram-process__step-btn"
              @click.stop="moveStep(step.id, 1)"
            >
              ➡
            </button>
          </div>
        </div>

        <div
          v-if="index < steps.length - 1"
          class="diagram-process__arrow"
        >
          →
        </div>
      </div>

      <p
        v-if="!steps.length"
        class="diagram-process__empty"
      >
        No hay pasos definidos. Usa los botones de arriba para agregar
        Inicio, Pasos, Decisiones y Fin.
      </p>
    </div>

    <p class="diagram-process__hint">
      Mapa de procesos simplificado. Las formas Inicio/Fin, Proceso y
      Decisión se representan como tarjetas con flujo secuencial. El
      refinamiento hacia BPMN completo queda fuera del alcance de F2.11.
    </p>
  </NodeViewWrapper>
</template>

<script setup lang="ts">
import { NodeViewWrapper } from '@tiptap/vue-3'
import { computed, onMounted, ref } from 'vue'

type StepKind = 'start' | 'process' | 'decision' | 'end'

interface ProcessStep {
  id: string
  kind: StepKind
  label: string
}

const props = defineProps<{
  node: {
    attrs: {
      title?: string
      description?: string
      steps?: ProcessStep[]
    }
  }
  updateAttributes: (attrs: Partial<{
    title: string
    description: string
    steps: ProcessStep[]
  }>) => void
}>()

const attrs = computed(() => props.node.attrs ?? {})

const localTitle = ref(attrs.value.title ?? '')
const localDescription = ref(attrs.value.description ?? '')

onMounted(() => {
  if (!Array.isArray(attrs.value.steps)) {
    props.updateAttributes({ steps: [] })
  }
})

const steps = computed<ProcessStep[]>(() => attrs.value.steps ?? [])

function stepId() {
  return `p_${Math.random().toString(36).slice(2, 9)}`
}

function commitTitle() {
  props.updateAttributes({ title: localTitle.value })
}

function commitDescription() {
  props.updateAttributes({ description: localDescription.value })
}

function cloneSteps(): ProcessStep[] {
  return steps.value.map((s) => ({ ...s }))
}

function kindLabel(kind: StepKind): string {
  switch (kind) {
    case 'start':
      return 'Inicio'
    case 'end':
      return 'Fin'
    case 'decision':
      return 'Decisión'
    default:
      return 'Proceso'
  }
}

function addStep(kind: StepKind) {
  const base =
    kind === 'start'
      ? 'Inicio del proceso'
      : kind === 'end'
        ? 'Fin del proceso'
        : kind === 'decision'
          ? 'Punto de decisión'
          : 'Paso de proceso'

  const label = window.prompt('Descripción del paso:', base)
  if (!label) return

  const newSteps = cloneSteps()
  newSteps.push({
    id: stepId(),
    kind,
    label,
  })
  props.updateAttributes({ steps: newSteps })
}

function editStep(stepIdValue: string) {
  const newSteps = cloneSteps()
  const step = newSteps.find((s) => s.id === stepIdValue)
  if (!step) return

  const next = window.prompt('Editar descripción del paso:', step.label)
  if (!next) return

  step.label = next
  props.updateAttributes({ steps: newSteps })
}

function removeStep(stepIdValue: string) {
  const ok = window.confirm('¿Eliminar este paso del proceso?')
  if (!ok) return

  const newSteps = cloneSteps().filter((s) => s.id !== stepIdValue)
  props.updateAttributes({ steps: newSteps })
}

function moveStep(stepIdValue: string, delta: number) {
  const newSteps = cloneSteps()
  const idx = newSteps.findIndex((s) => s.id === stepIdValue)
  if (idx === -1) return

  const targetIdx = idx + delta
  if (targetIdx < 0 || targetIdx >= newSteps.length) return

  const [step] = newSteps.splice(idx, 1)
  newSteps.splice(targetIdx, 0, step)
  props.updateAttributes({ steps: newSteps })
}
</script>

<style scoped>
.diagram-process {
  border: 1px solid #e5e7eb;
  border-radius: 0.75rem;
  padding: 0.75rem 1rem;
  background: #ffffff;
  font-size: 12px;
  color: #111827;
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
}

.diagram-process__header {
  display: flex;
  flex-direction: column;
  gap: 0.25rem;
}

.diagram-process__title-input {
  border-radius: 999px;
  border: 1px solid #d1d5db;
  padding: 2px 10px;
  font-size: 12px;
  font-weight: 600;
}

.diagram-process__description-input {
  border-radius: 0.75rem;
  border: 1px dashed #e5e7eb;
  padding: 4px 8px;
  font-size: 11px;
  resize: vertical;
}

.diagram-process__toolbar {
  display: flex;
  flex-wrap: wrap;
  gap: 4px;
  margin-top: 0.25rem;
}

.diagram-process__btn {
  border-radius: 999px;
  border: 1px solid #d1d5db;
  background: #f9fafb;
  padding: 3px 8px;
  font-size: 11px;
  cursor: pointer;
}

.diagram-process__flow {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 6px;
  margin-top: 0.25rem;
}

.diagram-process__step-wrapper {
  display: flex;
  align-items: center;
  gap: 4px;
}

.diagram-process__step {
  min-width: 120px;
  max-width: 180px;
  border-radius: 0.75rem;
  border: 1px solid #d1d5db;
  padding: 4px 6px;
  background: #f9fafb;
  display: flex;
  flex-direction: column;
  gap: 2px;
}

.diagram-process__step--start {
  border-style: solid;
  background: #ecfdf5;
}

.diagram-process__step--end {
  border-style: solid;
  background: #fef2f2;
}

.diagram-process__step--decision {
  border-style: dashed;
  background: #eff6ff;
}

.diagram-process__step--process {
  border-style: solid;
  background: #f9fafb;
}

.diagram-process__step-kind {
  font-size: 10px;
  font-weight: 600;
  color: #4b5563;
}

.diagram-process__step-label {
  font-size: 11px;
}

.diagram-process__step-actions {
  display: flex;
  justify-content: flex-end;
  gap: 2px;
}

.diagram-process__step-btn {
  border: none;
  background: transparent;
  cursor: pointer;
  font-size: 11px;
  padding: 0 2px;
}

.diagram-process__arrow {
  font-size: 18px;
  color: #9ca3af;
}

.diagram-process__empty {
  font-size: 11px;
  color: #6b7280;
}

.diagram-process__hint {
  font-size: 10px;
  color: #6b7280;
  margin: 0;
}
</style>
