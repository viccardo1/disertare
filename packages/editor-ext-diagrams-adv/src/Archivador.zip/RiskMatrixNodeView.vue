<!-- packages/editor-ext-diagrams-adv/src/RiskMatrixNodeView.vue -->
<template>
  <NodeViewWrapper class="diagram-risk">
    <header class="diagram-risk__header">
      <input
        v-model="localTitle"
        type="text"
        class="diagram-risk__title-input"
        :placeholder="'Título de la matriz de riesgo (opcional)'"
        @blur="commitTitle"
      />

      <textarea
        v-model="localDescription"
        class="diagram-risk__description-input"
        :placeholder="'Descripción del contexto / proyecto (opcional)'"
        rows="2"
        @blur="commitDescription"
      />
    </header>

    <div class="diagram-risk__controls">
      <label class="diagram-risk__size-label">
        Tamaño (N x N):
        <input
          v-model.number="localSize"
          type="number"
          min="3"
          max="7"
          class="diagram-risk__size-input"
          @change="commitSize"
        />
      </label>

      <button
        type="button"
        class="diagram-risk__add-risk"
        @click="addRisk"
      >
        + Agregar riesgo
      </button>
    </div>

    <div class="diagram-risk__matrix-wrapper">
      <table class="diagram-risk__matrix">
        <thead>
          <tr>
            <th />
            <th
              v-for="col in size"
              :key="'c-' + col"
            >
              Impacto {{ col }}
            </th>
          </tr>
        </thead>
        <tbody>
          <tr
            v-for="row in size"
            :key="'r-' + row"
          >
            <th>Prob {{ row }}</th>
            <td
              v-for="col in size"
              :key="`cell-${row}-${col}`"
              :class="[
                'diagram-risk__cell',
                cellSeverityClass(row, col),
              ]"
              @click="editCell(row, col)"
            >
              <div class="diagram-risk__cell-count">
                {{ cellRisks(row, col).length }}
              </div>
              <ul class="diagram-risk__cell-list">
                <li
                  v-for="risk in cellRisks(row, col)"
                  :key="risk.id"
                >
                  {{ risk.label }}
                </li>
              </ul>
            </td>
          </tr>
        </tbody>
      </table>
    </div>

    <p class="diagram-risk__hint">
      Matriz de riesgo Probabilidad × Impacto. Cada celda muestra cuántos
      riesgos están asignados a ese nivel. Haz clic en una celda para
      editar o mover los riesgos existentes.
    </p>
  </NodeViewWrapper>
</template>

<script setup lang="ts">
import { NodeViewWrapper } from '@tiptap/vue-3'
import { computed, onMounted, ref } from 'vue'

interface RiskItem {
  id: string
  label: string
  probability: number
  impact: number
}

const props = defineProps<{
  node: {
    attrs: {
      title?: string
      description?: string
      size?: number
      risks?: RiskItem[]
    }
  }
  updateAttributes: (attrs: Partial<{
    title: string
    description: string
    size: number
    risks: RiskItem[]
  }>) => void
}>()

const attrs = computed(() => props.node.attrs ?? {})

const localTitle = ref(attrs.value.title ?? '')
const localDescription = ref(attrs.value.description ?? '')
const localSize = ref<number>(attrs.value.size ?? 5)

onMounted(() => {
  // inicializar array vacío si no existe
  if (!Array.isArray(attrs.value.risks)) {
    props.updateAttributes({ risks: [] })
  }
})

const size = computed<number>(() => {
  const n = localSize.value || attrs.value.size || 5
  return Math.min(Math.max(n, 3), 7)
})

const risks = computed<RiskItem[]>(() => attrs.value.risks ?? [])

function riskId() {
  return `r_${Math.random().toString(36).slice(2, 9)}`
}

function commitTitle() {
  props.updateAttributes({ title: localTitle.value })
}

function commitDescription() {
  props.updateAttributes({ description: localDescription.value })
}

function commitSize() {
  props.updateAttributes({ size: size.value })
}

function cloneRisks(): RiskItem[] {
  return risks.value.map((r) => ({ ...r }))
}

function addRisk() {
  const label = window.prompt('Descripción del riesgo:')
  if (!label) return

  const pRaw = window.prompt(
    `Probabilidad (1-${size.value}):`,
    '3',
  )
  if (!pRaw) return
  const iRaw = window.prompt(
    `Impacto (1-${size.value}):`,
    '3',
  )
  if (!iRaw) return

  let p = Number(pRaw)
  let i = Number(iRaw)
  if (Number.isNaN(p) || Number.isNaN(i)) return

  p = Math.min(Math.max(p, 1), size.value)
  i = Math.min(Math.max(i, 1), size.value)

  const newRisks = cloneRisks()
  newRisks.push({
    id: riskId(),
    label,
    probability: p,
    impact: i,
  })
  props.updateAttributes({ risks: newRisks })
}

function cellRisks(row: number, col: number): RiskItem[] {
  return risks.value.filter(
    (r) => r.probability === row && r.impact === col,
  )
}

function severityScore(row: number, col: number): number {
  return row * col
}

function cellSeverityClass(row: number, col: number): string {
  const score = severityScore(row, col)
  const maxScore = size.value * size.value
  const ratio = score / maxScore

  if (ratio > 0.66) return 'diagram-risk__cell--high'
  if (ratio > 0.33) return 'diagram-risk__cell--medium'
  return 'diagram-risk__cell--low'
}

function editCell(row: number, col: number) {
  const inCell = cellRisks(row, col)
  if (!inCell.length) {
    // si está vacía, ofrecer crear uno directamente
    const add = window.confirm(
      'No hay riesgos en esta celda. ¿Agregar uno nuevo aquí?',
    )
    if (add) {
      const label = window.prompt('Descripción del riesgo:')
      if (!label) return

      const newRisks = cloneRisks()
      newRisks.push({
        id: riskId(),
        label,
        probability: row,
        impact: col,
      })
      props.updateAttributes({ risks: newRisks })
    }
    return
  }

  const labels = inCell
    .map((r, idx) => `${idx + 1}) ${r.label}`)
    .join('\n')
  const choiceRaw = window.prompt(
    `Riesgos en esta celda:\n${labels}\n\nIngresa el número a editar o dejar vacío para cancelar:`,
  )
  if (!choiceRaw) return

  const idx = Number(choiceRaw) - 1
  if (Number.isNaN(idx) || idx < 0 || idx >= inCell.length) return

  const target = inCell[idx]
  const action = window.prompt(
    'Escribe "mover" para cambiar probabilidad/impacto, "editar" para cambiar texto o "eliminar" para borrar:',
    'editar',
  )

  if (!action) return

  if (action.toLowerCase() === 'eliminar') {
    const confirmDelete = window.confirm(
      '¿Eliminar definitivamente este riesgo?',
    )
    if (!confirmDelete) return

    const newRisks = cloneRisks().filter((r) => r.id !== target.id)
    props.updateAttributes({ risks: newRisks })
    return
  }

  if (action.toLowerCase() === 'editar') {
    const next = window.prompt(
      'Editar descripción del riesgo:',
      target.label,
    )
    if (!next) return

    const newRisks = cloneRisks()
    const r = newRisks.find((x) => x.id === target.id)
    if (!r) return
    r.label = next
    props.updateAttributes({ risks: newRisks })
    return
  }

  if (action.toLowerCase() === 'mover') {
    const pRaw = window.prompt(
      `Nueva probabilidad (1-${size.value}):`,
      String(target.probability),
    )
    if (!pRaw) return
    const iRaw = window.prompt(
      `Nuevo impacto (1-${size.value}):`,
      String(target.impact),
    )
    if (!iRaw) return

    let p = Number(pRaw)
    let i = Number(iRaw)
    if (Number.isNaN(p) || Number.isNaN(i)) return

    p = Math.min(Math.max(p, 1), size.value)
    i = Math.min(Math.max(i, 1), size.value)

    const newRisks = cloneRisks()
    const r = newRisks.find((x) => x.id === target.id)
    if (!r) return

    r.probability = p
    r.impact = i
    props.updateAttributes({ risks: newRisks })
  }
}
</script>

<style scoped>
.diagram-risk {
  border: 1px solid #e5e7eb;
  border-radius: 0.75rem;
  padding: 0.75rem 1rem;
  background: #ffffff;
  font-size: 12px;
  color: #111827;
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
}

.diagram-risk__header {
  display: flex;
  flex-direction: column;
  gap: 0.25rem;
}

.diagram-risk__title-input {
  border-radius: 999px;
  border: 1px solid #d1d5db;
  padding: 2px 10px;
  font-size: 12px;
  font-weight: 600;
}

.diagram-risk__description-input {
  border-radius: 0.75rem;
  border: 1px dashed #e5e7eb;
  padding: 4px 8px;
  font-size: 11px;
  resize: vertical;
}

.diagram-risk__controls {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 0.5rem;
  margin-top: 0.25rem;
}

.diagram-risk__size-label {
  font-size: 11px;
  display: flex;
  align-items: center;
  gap: 4px;
}

.diagram-risk__size-input {
  width: 48px;
  border-radius: 999px;
  border: 1px solid #d1d5db;
  padding: 1px 6px;
  font-size: 11px;
}

.diagram-risk__add-risk {
  border-radius: 999px;
  border: none;
  background: #4f46e5;
  color: #ffffff;
  padding: 4px 10px;
  font-size: 11px;
  cursor: pointer;
}

.diagram-risk__matrix-wrapper {
  overflow-x: auto;
}

.diagram-risk__matrix {
  border-collapse: collapse;
  width: 100%;
  font-size: 11px;
}

.diagram-risk__matrix th,
.diagram-risk__matrix td {
  border: 1px solid #d1d5db;
  padding: 3px 4px;
  text-align: center;
}

.diagram-risk__matrix thead th {
  background: #f3f4f6;
}

.diagram-risk__cell {
  min-width: 70px;
  cursor: pointer;
  vertical-align: top;
}

.diagram-risk__cell-count {
  font-weight: 600;
}

.diagram-risk__cell-list {
  list-style: none;
  margin: 0;
  padding: 0;
  text-align: left;
}

.diagram-risk__cell--low {
  background: #ecfdf5;
}

.diagram-risk__cell--medium {
  background: #fef3c7;
}

.diagram-risk__cell--high {
  background: #fee2e2;
}

.diagram-risk__hint {
  font-size: 10px;
  color: #6b7280;
  margin: 0;
}
</style>
